
/*These are almost identical to the Veritical Flip Filter.  I am not goint to 
 *explain these */
HFlipFilter::HFlipFilter ()  {

}

HFlipFilter::HFlipFilter (const HFlipFilter& hflp)  {

}

void HFlipFilter::apply(Image& img) const {
  
}

ostream& HFlipFilter::print(ostream& out) const {
  
  
}

HFlipFilter& HFlipFilter::operator=(const HFlipFilter& hflp) {
  
  
}

ostream& operator<< (ostream& out, const HFlipFilter& hflp) {
  
  
}
