
/*Filter is the base class here so call the Filter regular constructor. */
SimpleFilter::SimpleFilter () {

}

/*Filter is the base class here so call the Filter regular constructor. */
SimpleFilter::SimpleFilter (string name) {

}

/*Filter is the base class here so call the Filter regular constructor. */
SimpleFilter::SimpleFilter (const SimpleFilter& smpl) {

}

/*Calls Filter's print function and then outputs information of the 
Simple Filter */
ostream& SimpleFilter::print(ostream& out) const {
 
}

/*Assignment operator:  calls the filter's assignment operator passing in the
 *simpleFilter info*/
SimpleFilter& SimpleFilter::operator=(const SimpleFilter& smpl) {
  
}

/*Calls the print function for the smpl class*/
ostream& operator<< (ostream& out, const SimpleFilter& smpl) {
  
}
